import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import WebNovelUploader from './WebNovelUploader'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <WebNovelUploader />
  </React.StrictMode>,
)
